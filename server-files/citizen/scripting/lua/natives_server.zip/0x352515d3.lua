--- Returns red ( default ) blip attached to entity.
-- Example:
-- Blip blip; //Put this outside your case or option
-- blip = HUD::ADD_BLIP_FOR_ENTITY(YourPedOrBodyguardName);
-- HUD::SET_BLIP_AS_FRIENDLY(blip, true);
function Global.AddBlipForEntity(entity)
	return _in(0x30822554, entity, _ri)
end
