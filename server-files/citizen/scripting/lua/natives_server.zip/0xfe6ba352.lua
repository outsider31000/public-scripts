function Global.GetVehicleRoofLivery(vehicle)
	return _in(0x872cf42, vehicle, _ri)
end
