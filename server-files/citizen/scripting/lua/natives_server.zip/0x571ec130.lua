function Global.NetworkGetNetworkIdFromEntity(entity)
	return _in(0x9e35dab6, entity, _ri)
end
