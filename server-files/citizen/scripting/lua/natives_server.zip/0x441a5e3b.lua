function Global.GetPedCauseOfDeath(ped)
	return _in(0x63458c27, ped, _ri)
end
